#!/bin/sh

make && cp src/squid /usr/local/squid/sbin/squid 
md5sum src/squid /usr/local/squid/sbin/squid 

/*
 * Auto-Generated File. Changes will be destroyed.
 */
#include "squid.h"
#include "err_detail_type.h"

const char *err_detail_type_str[] = {
	"NONE",
	"START",
	"CLT_REQMOD_ABORT",
	"CLT_REQMOD_REQ_BODY",
	"CLT_REQMOD_RESP_BODY",
	"SRV_REQMOD_REQ_BODY",
	"ICAP_RESPMOD_EARLY",
	"ICAP_RESPMOD_LATE",
	"REQMOD_BLOCK",
	"RESPMOD_BLOCK_EARLY",
	"RESPMOD_BLOCK_LATE",
	"ICAP_XACT_START",
	"ICAP_XACT_BODY_CONSUMER_ABORT",
	"ICAP_INIT_GONE",
	"ICAP_XACT_CLOSE",
	"ICAP_XACT_OTHER",
	"EXCEPTION_OTHER",
	"MAX",
	"EXCEPTION_START"
};
